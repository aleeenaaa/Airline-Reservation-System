<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<h2>Contact Us</h2>
            <p>If you have any questions or need assistance, feel free to contact us:</p>
            <ul>
                <li><strong>Email:</strong> support@airline.com</li>
                <li><strong>Phone:</strong> +123-456-7890</li>
                <li><strong>Address:</strong> 123 Airline Ave, Travel City, World</li>
            </ul>
            <p>We’re here to help 24/7!</p>
    <a href="index.html">Back to Home</a>
</body>
</html>
