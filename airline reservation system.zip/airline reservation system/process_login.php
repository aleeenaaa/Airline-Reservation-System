<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username']; // Get username from the form
    $password = $_POST['password']; // Get password from the form

    // Example logic to allow any username and password
    $_SESSION['user_id'] = rand(1, 1000); // Generate a random user ID
    $_SESSION['username'] = $username; // Store the provided username in the session

    // Redirect to the index page (home page)
    header("Location: index.html");
    exit;
} else {
    echo "Invalid request method.";
}
?>
