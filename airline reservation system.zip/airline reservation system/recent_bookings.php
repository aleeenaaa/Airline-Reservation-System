<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    die("Error: You must be logged in to view your bookings.");
}

$user_id = $_SESSION['user_id'];

// Fetch bookings for the logged-in user
$query = "SELECT payments.payment_id, flights.flight_name, flights.departure_city, flights.arrival_city, 
                 flights.departure_date, flights.departure_time, payments.payment_status
          FROM payments
          INNER JOIN flights ON payments.flight_id = flights.id
          WHERE payments.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<h1>My Recent Bookings</h1>
<table border="1">
    <tr>
        <th>Flight Name</th>
        <th>From</th>
        <th>To</th>
        <th>Departure Date</th>
        <th>Departure Time</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['flight_name']) ?></td>
            <td><?= htmlspecialchars($row['departure_city']) ?></td>
            <td><?= htmlspecialchars($row['arrival_city']) ?></td>
            <td><?= htmlspecialchars($row['departure_date']) ?></td>
            <td><?= htmlspecialchars($row['departure_time']) ?></td>
            <td><?= htmlspecialchars($row['payment_status']) ?></td>
            <td>
                <?php if ($row['payment_status'] !== 'Cancelled'): ?>
                    <a href="cancel_booking.php?payment_id=<?= $row['payment_id'] ?>" 
                       onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel</a>
                <?php else: ?>
                    Cancelled
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

