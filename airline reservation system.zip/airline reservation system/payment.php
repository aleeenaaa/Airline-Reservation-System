<?php
if (isset($_GET['flight_id'])) {
    $flight_id = $_GET['flight_id'];
    // Use $flight_id to fetch flight details or process booking
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="payment-container">
        <h1>Confirm Payment</h1>
        <form action="process_booking.php" method="post">
            <input type="hidden" name="flight_id" value="<?php echo $flight_id; ?>">

            <label for="card_name">Cardholder Name:</label>
            <input type="text" id="card_name" name="card_name" required placeholder="Enter cardholder name">

            <label for="card_number">Card Number:</label>
            <input type="text" id="card_number" name="card_number" required placeholder="Enter card number">

            <label for="expiry_date">Expiry Date:</label>
            <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YY" required>

            <label for="cvv">CVV:</label>
            <input type="number" id="cvv" name="cvv" required placeholder="Enter CVV">

            <label for="payment_amount">Payment Amount:</label>
            <input type="text" id="payment_amount" name="payment_amount" value="1000" readonly>

            <button type="submit">Confirm Booking</button>
        </form>
    </div>
</body>
</html>
