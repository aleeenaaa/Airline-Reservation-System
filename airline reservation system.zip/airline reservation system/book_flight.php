<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.html');
    exit();
}

$flight_id = $_GET['flight_id'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Flight</title>
</head>
<body>
    <h2>Enter Payment Details</h2>
    <form action="process_booking.php" method="post">
        <input type="hidden" name="flight_id" value="<?php echo $flight_id; ?>">
        <label>Card Name:</label>
        <input type="text" name="card_name" required><br>
        <label>Card Number:</label>
        <input type="text" name="card_number" required><br>
        <label>Expiry Date:</label>
        <input type="text" name="expiry_date" required><br>
        <label>CVV:</label>
        <input type="text" name="cvv" required><br>
        <button type="submit">Confirm Booking</button>
    </form>
</body>
</html>
