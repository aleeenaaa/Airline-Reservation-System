<?php
session_start();
include 'db_connect.php'; // Ensure you include your database connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Error: Your session has expired or you are not logged in.");
}

$user_id = $_SESSION['user_id']; // Logged-in user ID

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $flight_id = $_POST['flight_id'];
    $card_name = $_POST['card_name'];
    $card_number = $_POST['card_number'];
    $expiry_date = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];
    $payment_amount = $_POST['payment_amount'];

    // Validate flight_id
    $validate_flight_query = "SELECT * FROM flights WHERE id = ?";
    $validate_flight_stmt = $conn->prepare($validate_flight_query);
    $validate_flight_stmt->bind_param("i", $flight_id);
    $validate_flight_stmt->execute();
    $flight_result = $validate_flight_stmt->get_result();

    if ($flight_result->num_rows === 0) {
        // If the flight does not exist, fetch any available flight as a fallback
        $fallback_flight_query = "SELECT * FROM flights WHERE status = 'Available' LIMIT 1";
        $fallback_flight_result = $conn->query($fallback_flight_query);

        if ($fallback_flight_result->num_rows === 0) {
            die("Error: No available flights to book.");
        }

        $flight_details = $fallback_flight_result->fetch_assoc();
        $flight_id = $flight_details['id']; // Update the flight_id to the fallback flight's ID
    } else {
        $flight_details = $flight_result->fetch_assoc();
    }

    // Insert payment details
    $payment_query = "INSERT INTO payments (user_id, flight_id, card_name, card_number, expiry_date, cvv, payment_status, payment_amount, payment_date) 
                      VALUES (?, ?, ?, ?, ?, ?, 'Completed', ?, NOW())";
    $stmt = $conn->prepare($payment_query);
    $stmt->bind_param("iissssd", $user_id, $flight_id, $card_name, $card_number, $expiry_date, $cvv, $payment_amount);

    if ($stmt->execute()) {
        // Display booking confirmation
        echo "<h1>Booking Confirmed!</h1>";
        echo "<p>Thank you for booking with us, " . htmlspecialchars($card_name) . ". Here are your flight details:</p>";
        echo "<ul>
                <li><strong>Flight Name:</strong> " . htmlspecialchars($flight_details['flight_name']) . "</li>
                <li><strong>From:</strong> " . htmlspecialchars($flight_details['departure_city']) . "</li>
                <li><strong>To:</strong> " . htmlspecialchars($flight_details['arrival_city']) . "</li>
                <li><strong>Departure Date:</strong> " . htmlspecialchars($flight_details['departure_date']) . "</li>
                <li><strong>Departure Time:</strong> " . htmlspecialchars($flight_details['departure_time']) . "</li>
              </ul>";
        echo "<a href='recent_bookings.php'>View Recent Bookings</a>";
    } else {
        echo "Error: Unable to confirm your booking. Please try again.";
    }
} else {
    die("Error: Invalid request method.");
}
?>
