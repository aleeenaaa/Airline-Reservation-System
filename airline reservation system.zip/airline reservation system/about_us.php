<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>About Us</h1>
    <p>We are a leading airline reservation service providing the best user experience for booking flights around the globe. Our system is fast, secure, and easy to use. We strive to make your travel seamless and enjoyable.</p>
            <p>Our mission is to bring convenience to travelers by offering a one-stop platform for finding and booking the perfect flights at competitive prices.</p>
    <a href="index.html">Back to Home</a>
</body>
</html>
