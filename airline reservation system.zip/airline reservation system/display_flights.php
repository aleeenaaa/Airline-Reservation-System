<?php
// Database connection
include 'db_connect.php';

// Capture user input
$departure_city = isset($_POST['departure_city']) ? $_POST['departure_city'] : '';
$arrival_city = isset($_POST['arrival_city']) ? $_POST['arrival_city'] : '';
$departure_date = isset($_POST['departure_date']) ? $_POST['departure_date'] : '';

// Prepare SQL query
$query = "SELECT * FROM flights WHERE 1=1";

// Add filters based on user input
if (!empty($departure_city)) {
    $query .= " AND departure_city LIKE '%" . mysqli_real_escape_string($conn, $departure_city) . "%'";
}
if (!empty($arrival_city)) {
    $query .= " AND arrival_city LIKE '%" . mysqli_real_escape_string($conn, $arrival_city) . "%'";
}
if (!empty($departure_date)) {
    $query .= " AND departure_date = '" . mysqli_real_escape_string($conn, $departure_date) . "'";
}

// Execute the query
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}

// Start output
echo "<table border='1'>
        <tr>
            <th>Flight Name</th>
            <th>From</th>
            <th>To</th>
            <th>Departure Date</th>
            <th>Departure Time</th>
            <th>Status</th>
            <th>Action</th>
        </tr>";

// Check if query returns any results
if (mysqli_num_rows($result) > 0) {
    // Display flights from the database
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['flight_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['departure_city']) . "</td>";
        echo "<td>" . htmlspecialchars($row['arrival_city']) . "</td>";
        echo "<td>" . htmlspecialchars($row['departure_date']) . "</td>";
        echo "<td>" . htmlspecialchars($row['departure_time']) . "</td>";
        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
        echo "<td>
                <a href='book_flight.php?flight_id=" . $row['id'] . "'>Book Now</a> |
                <a href='payment.php?flight_id=" . $row['id'] . "'>Proceed to Payment</a>
              </td>";
        echo "</tr>";
    }
} else {
    // Display a default flight if no results are found
    echo "<tr>
            <td>Default Flight</td>
            <td>Any City</td>
            <td>Any City</td>
            <td>2024-12-31</td>
            <td>12:00</td>
            <td>Available</td>
            <td>
                <a href='book_flight.php?flight_id=999'>Book Now</a> |
                <a href='payment.php?flight_id=999'>Proceed to Payment</a>
            </td>
          </tr>";
}

echo "</table>";
?>
