<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    die("Error: You must be logged in to cancel a booking.");
}

if (isset($_GET['payment_id'])) {
    $payment_id = $_GET['payment_id'];

    // Cancel the booking by updating the payment status
    $query = "UPDATE payments SET payment_status = 'Cancelled' WHERE payment_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $payment_id);

    if ($stmt->execute()) {
        echo "<h1>Booking Cancelled</h1>";
        echo "<p>Your booking has been successfully cancelled.</p>";
        echo "<a href='recent_bookings.php'>Back to Recent Bookings</a>";
    } else {
        echo "Error: Unable to cancel the booking.";
    }
} else {
    echo "Error: Invalid request.";
}
?>
